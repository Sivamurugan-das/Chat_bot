import streamlit as st
import pandas as pd
import time
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from transformers import BertTokenizer

# Load the BERT tokenizer
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')

# Define the solutions dictionary
solutions = {
    'ORDER': "If you're having trouble placing an order, ensure all required information is correctly filled out in the checkout process.\nDouble-check the items in your cart and payment details before confirming your order.\nIf the issue persists, contact customer support for assistance.",
    'SHIPPING_ADDRESS': "To update your shipping address, log in to your account and navigate to the shipping address section.\nEnter the new address details and save the changes.\nIf you encounter any difficulties, contact customer support for guidance.",
    'CANCELLATION_FEE': "Before canceling your order, review the cancellation policy to understand any applicable fees.\nIf you decide to proceed with the cancellation, do it within the specified timeframe to minimize fees. \nContact customer support for assistance with the cancellation process and fee inquiries.",
    'INVOICE': "If you need a copy of your invoice, log in to your account and navigate to the order history or billing section.\nYou can usually download or print invoices from there.\nFor any invoice-related queries or discrepancies, contact customer support for assistance.",
    'PAYMENT': "If you're experiencing payment issues, ensure your payment information is correct and up-to-date.\nTry using a different payment method or contact your bank to verify transaction status.\nFor further assistance, reach out to customer support or the billing department.",
    'REFUND': "To request a refund, log in to your account and navigate to the order history or refund section.\n Follow the instructions to initiate a refund request and provide relevant details about your purchase.\nCustomer support will process your refund request and provide further assistance if needed.",
    'FEEDBACK': "We value your feedback! Please take a moment to share your thoughts or suggestions with us.\nYour feedback helps us improve our products and services to better meet your needs.\nYou can leave feedback through our website, social media channels, or directly contact customer support.",
    'CONTACT': "If you need assistance or have any questions, don't hesitate to contact us. Our customer support team is available to help you with any inquiries or issues you may have.\nYou can reach us via phone, email, or live chat during our business hours.",
    'ACCOUNT': "To manage your account settings, log in to your account dashboard.\n From there, you can update personal information, change passwords, or modify communication preferences.\nIf you encounter any account-related issues, contact customer support for assistance.",
    'DELIVERY': "If you're experiencing delivery problems, such as delays or missing packages,\ncontact the shipping carrier or logistics provider for assistance. Provide them with your tracking information and any relevant details to resolve the issue promptly.",
    'NEWSLETTER': "Stay informed and connected by subscribing to our newsletter! Receive updates on new products, promotions, and exclusive offers straight to your inbox.\nYou can manage your newsletter subscription preferences in your account settings or contact customer support for assistance."
}

def preprocess_text(text):
    tokens = tokenizer.tokenize(text)
    tokens_lower = [token.lower() for token in tokens]
    preprocessed_text = " ".join(tokens_lower)
    return preprocessed_text

# Create the pipeline
text_clf = Pipeline([
    ('tfidf', TfidfVectorizer(preprocessor=preprocess_text)),
    ('clf', MultinomialNB())
])

# Load and prepare the data (replace with your actual data)
df = pd.read_csv(r"Bitext_Sample_Customer_Service_Testing_Dataset.csv")

X = df['utterance']
y = df['category']

# Train the model
text_clf.fit(X, y)

st.title("Customer Support Chatbot")

def display_welcome_message():
    available_categories = df['category'].unique()
    welcome_message = (
        "Welcome to the customer support chatbot! If you are experiencing any issues, please describe "
        "them, and I'll try to assist you. Please select the type of issue you are facing from the following "
        "categories:\n\n"
    )
    for idx, category in enumerate(available_categories, 1):
        welcome_message += f"{idx}. {category}\n"
    welcome_message += "\nIf you are not sure about the category, explain the issue that you are facing."
    
    st.session_state.messages.append({"role": "assistant", "content": welcome_message})

if "messages" not in st.session_state:
    st.session_state.messages = []
    display_welcome_message()  # Only display the welcome message when initializing
if "waiting_for_category" not in st.session_state:
    st.session_state.waiting_for_category = False
if "waiting_for_confirmation" not in st.session_state:
    st.session_state.waiting_for_confirmation = False
if "predicted_category" not in st.session_state:
    st.session_state.predicted_category = None
if "failed_attempts" not in st.session_state:
    st.session_state.failed_attempts = 0
if "awaiting_human_response" not in st.session_state:
    st.session_state.awaiting_human_response = False

# Display chat messages from history
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# React to user input
if prompt := st.chat_input("You: "):
    # Display user message in chat message container
    st.chat_message("user").markdown(prompt)
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})

    # Process user input
    user_input = prompt.lower()

    # Check if the user is thanking the chatbot
    if 'thanks' in user_input or 'thank you' in user_input:
        response = "Chatbot: You're welcome! If you need any further assistance, feel free to ask. Goodbye!"
        with st.chat_message("assistant"):
            st.markdown(response)
        st.session_state.messages.append({"role": "assistant", "content": response})
        st.stop()  # Exit the chat

    if st.session_state.awaiting_human_response:
        if user_input == 'yes':
            response = "Connecting to human support..."
            time.sleep(4)
            response = "Chatbot: You are now connected to human support. Please provide your issue details."
        else:
            response = "Chatbot: Let's try again. Please provide more details about your issue."
            st.session_state.failed_attempts = 0
        st.session_state.awaiting_human_response = False
    else:
        if user_input in [cat.lower() for cat in df['category'].unique()]:
            response = f"Chatbot: You selected '{user_input}'. Is that correct? (yes/no)"
            st.session_state.waiting_for_confirmation = True
            st.session_state.predicted_category = user_input
        elif st.session_state.waiting_for_confirmation:
            if user_input == 'yes':
                response = f"Chatbot: Here's some Solution for your issue:\n\n{solutions[st.session_state.predicted_category.upper()]}"
                st.session_state.waiting_for_confirmation = False
                st.session_state.failed_attempts = 0
            else:
                response = "Chatbot: Let's try again. Please provide more details about your issue."
                st.session_state.waiting_for_confirmation = False
                st.session_state.failed_attempts += 1
        else:
            predicted_category = text_clf.predict([user_input])[0]
            response = f"Chatbot: Your query seems related to '{predicted_category}'. Is that correct? (yes/no)"
            st.session_state.waiting_for_confirmation = True
            st.session_state.predicted_category = predicted_category
            st.session_state.failed_attempts += 1

        # If the bot fails to understand the category after 3 attempts, redirect to human interface
        if st.session_state.failed_attempts >= 3:
            response = "Chatbot: I'm sorry, I couldn't understand your issue. Do you want to connect with human support for further assistance? (yes/no)"
            st.session_state.awaiting_human_response = True
            st.session_state.failed_attempts = 0

    # Display assistant response in chat message container
    with st.chat_message("assistant"):
        st.markdown(response)
    # Add assistant response to chat history
    st.session_state.messages.append({"role": "assistant", "content": response})
    